// Placeholder controller for order-related APIs (create, update, fetch, etc.)
export const test = (req, res) => {
  res.json({ message: 'Order controller ready' });
};